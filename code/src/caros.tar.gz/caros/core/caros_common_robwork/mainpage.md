\mainpage
<!-- markdown-toc start - Don't edit this section. Run M-x markdown-toc/generate-toc again -->
**Table of Contents**

- [caros_common_robwork](#caroscommonrobwork)

<!-- markdown-toc end -->

# caros_common_robwork #
caros_common_robwork is a collection of RobWork oriented, or related, functionality that is used by the various CAROS nodes.

See [modules](modules.html) for the different categories.
