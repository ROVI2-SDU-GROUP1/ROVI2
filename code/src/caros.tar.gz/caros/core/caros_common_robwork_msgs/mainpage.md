\mainpage
<!-- markdown-toc start - Don't edit this section. Run M-x markdown-toc/generate-toc again -->
**Table of Contents**

- [caros_common_robwork_msgs](#caroscommonrobworkmsgs)

<!-- markdown-toc end -->

# caros_common_robwork_msgs #
This component contains messages and services that are dependent on RobWork and commonly used throughout CAROS.
