\mainpage
<!-- markdown-toc start - Don't edit this section. Run M-x markdown-toc/generate-toc again -->
**Table of Contents**

- [caros_common_msgs](#caroscommonmsgs)

<!-- markdown-toc end -->

# caros_common_msgs #
This component contains messages and services that are commonly used throughout CAROS.
